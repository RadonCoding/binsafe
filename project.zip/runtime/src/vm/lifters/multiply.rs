use iced_x86::{Instruction, Mnemonic};


use crate::vm::bytecode::{VMReg, VMWidth};
use crate::vm::encoders::{
    discard::Discard, load_immediate::LoadImmediate, load_register::LoadRegister, mul::Mul,
    store_register::StoreRegister, Encode,
};
use crate::vm::lifters::{operation_immediate, operation_width, source};

pub fn encode(instruction: &Instruction) -> Option<Vec<Box<dyn Encode>>> {
    match instruction.mnemonic() {
        Mnemonic::Mul => wide(instruction, |width| Mul { width }),
        Mnemonic::Imul if instruction.op_count() == 1 => wide(instruction, |width| Mul {
            width: width.signed(),
        }),
        Mnemonic::Imul => narrow(instruction),
        mnemonic => panic!("unsupported mnemonic: {mnemonic:?}"),
    }
}

pub fn wide<O: Encode + 'static>(
    instruction: &Instruction,
    make: impl Fn(VMWidth) -> O,
) -> Option<Vec<Box<dyn Encode>>> {
    let mut operations = Vec::<Box<dyn Encode>>::new();

    let width = operation_width(instruction, 0);

    operations.push(Box::new(LoadRegister {
        width,
        source: VMReg::Rax,
    }));

    source(&mut operations, instruction, 0, width)?;

    operations.push(Box::new(make(width)));

    match width {
        VMWidth::Lower8 | VMWidth::Higher8 => {
            operations.push(Box::new(StoreRegister {
                width: VMWidth::Lower8,
                destination: VMReg::Rax,
            }));
            operations.push(Box::new(StoreRegister {
                width: VMWidth::Higher8,
                destination: VMReg::Rax,
            }));
        }
        _ => {
            operations.push(Box::new(StoreRegister {
                width,
                destination: VMReg::Rax,
            }));
            operations.push(Box::new(StoreRegister {
                width,
                destination: VMReg::Rdx,
            }));
        }
    }

    Some(operations)
}

pub fn narrow(instruction: &Instruction) -> Option<Vec<Box<dyn Encode>>> {
    let mut operations = Vec::<Box<dyn Encode>>::new();

    let destination_width = VMWidth::from(instruction.op0_register());
    let destination_register = VMReg::from(instruction.op0_register());

    match instruction.op_count() {
        2 => {
            operations.push(Box::new(LoadRegister {
                width: destination_width,
                source: destination_register,
            }));
            source(&mut operations, instruction, 1, destination_width)?;
        }
        3 => {
            source(&mut operations, instruction, 1, destination_width)?;

            let immediate_source = operation_immediate(instruction, instruction.op_kind(2));
            let immediate_width = operation_width(instruction, 2);
            operations.push(Box::new(LoadImmediate {
                width: immediate_width,
                source: immediate_source.to_le_bytes()[..immediate_width.size()].to_vec(),
            }));
        }
        _ => unreachable!(),
    }

    operations.push(Box::new(Mul {
        width: destination_width.signed(),
    }));
    operations.push(Box::new(StoreRegister {
        width: destination_width,
        destination: destination_register,
    }));
    operations.push(Box::new(Discard));

    Some(operations)
}
